import type { Domain } from "./modules.ts";
import type { Context, Entity } from "./core.ts";
import { uid, json, parse, type Row } from "./db.ts";
import { check, Problem, text } from "./validation.ts";
import { Knowledge } from "./knowledge.ts";

const normalized = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
export const conversational = (s: string) =>
  s
    .replace(/^\/?nanba\b[\s,:-]*/i, "")
    .replace(/^@\S+\s*/, "")
    .replace(/^\//, "")
    .trim();
const short = (r: Row) => r.id.slice(0, 8);
export class Conversation {
  app: Domain;
  constructor(app: Domain) {
    this.app = app;
  }
  enabled(group: Row) {
    return parse(group.settings).assistantEnabled === true;
  }
  handle(p: Row): boolean {
    const a = this.app,
      group = a.db.get("SELECT * FROM groups WHERE id=?", p.groupId)!;
    if (!this.enabled(group)) return false;
    if (
      group.paused ||
      a.db.get("SELECT value FROM settings WHERE key='global_pause'")?.value ===
        "true"
    )
      return true;
    const service = a.db.get(
      "SELECT m.user_id FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.group_id=? AND m.active=1 AND u.deleted=0 AND (m.role='group_admin' OR u.platform_admin=1) ORDER BY u.platform_admin DESC LIMIT 1",
      p.groupId,
    );
    if (!service) return true;
    const actor = { userId: service.user_id, groupId: p.groupId };
    // Rate limits and deduplication are transactional with inbox consumption.
    const rateKey = "conversation:" + p.groupId + ":" + p.identityHash;
    const rate = a.db.get("SELECT * FROM rate_limits WHERE key=?", rateKey);
    if (rate && rate.reset_at > a.now() && rate.count >= 15) return true;
    a.db.run(
      "INSERT INTO rate_limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN reset_at<=? THEN 1 ELSE count+1 END,reset_at=CASE WHEN reset_at<=? THEN excluded.reset_at ELSE reset_at END",
      rateKey,
      a.now() + 60000,
      a.now(),
      a.now(),
    );
    const identity = a.db.get(
      "SELECT * FROM identities WHERE identity_hash=?",
      p.identityHash,
    )!;
    const content = conversational(p.body),
      command = normalized(content);
    if (["pause", "stop"].includes(command) && identity.user_id) {
      try {
        a.admin({ userId: identity.user_id, groupId: p.groupId });
      } catch {
        return true;
      }
      a.db.run("UPDATE groups SET paused=1 WHERE id=?", p.groupId);
      a.db.run(
        "UPDATE outbox SET status='cancelled',error='group_paused',updated_at=? WHERE group_id=? AND status IN('pending','prepared')",
        a.now(),
        p.groupId,
      );
      a.audit(
        { userId: identity.user_id, groupId: p.groupId },
        "assistant.paused",
      );
      return true;
    }
    let reply: string;
    try {
      if (["rejoindre", "join"].includes(command)) {
        let userId = identity.user_id;
        if (!userId) {
          userId = uid();
          a.db.run(
            "INSERT INTO users VALUES(?,?,?,?,0,NULL,'{}',0,?)",
            userId,
            "whatsapp-" + userId + "@nanba.invalid",
            "Membre WhatsApp",
            "!whatsapp-only",
            a.now(),
          );
          a.db.run(
            "UPDATE identities SET user_id=?,verified_at=? WHERE identity_hash=?",
            userId,
            a.now(),
            p.identityHash,
          );
        }
        const membership = a.db.get(
          "SELECT active FROM memberships WHERE user_id=? AND group_id=?",
          userId,
          p.groupId,
        );
        check(!membership || membership.active, "membership_revoked", 403);
        a.db.run(
          "INSERT OR IGNORE INTO memberships VALUES(?,?,'member',1)",
          userId,
          p.groupId,
        );
        reply =
          "C’est enregistré : tu peux utiliser Nanba dans cette discussion. Ton profil est lié à ton identifiant WhatsApp. Écris « Nanba proposer une sortie » pour commencer. Aucun accès aux autres groupes n’est accordé.";
      } else if (
        [
          "",
          "aide",
          "help",
          "menu",
          "bonjour",
          "salut",
          "hello",
          "hi",
          "vanakkam",
        ].includes(command)
      ) {
        reply =
          "Vanakkam 👋 Je suis Nanba, l’assistant de la communauté indienne en France.\n\nPour tester ici :\n• Nanba proposer une sortie à Paris\n• Nanba demandes\n• Nanba sondage CODE\n• Nanba résultats CODE\n• Nanba rencontres / offres / radar / arrivée / défis / histoires\n• Nanba rechercher un sujet\n• Nanba annuler\n\nCommence chaque message par « Nanba ». Pilote guidé : je m’appuie sur les données enregistrées, sans inventer d’offres ni de réservation. Je ne suis pas encore connecté à un modèle d’IA généraliste. Les votes de sondage ne sont pas anonymes pour Nanba.";
        if (!identity.user_id)
          reply +=
            "\n\nPour participer, écris « Nanba rejoindre ». Cela crée ton profil minimal dans ce groupe et conserve les commandes adressées à Nanba.";
      } else if (!identity.user_id) {
        reply =
          "Pour enregistrer ta demande dans ce groupe, écris d’abord « Nanba rejoindre ». Ton identifiant WhatsApp et les commandes adressées à Nanba seront conservés ; les conversations ordinaires sont ignorées.";
      } else {
        const c = { userId: identity.user_id, groupId: p.groupId };
        a.member(c);
        reply = this.respond(c, p, content, command);
      }
    } catch (e) {
      if (!(e instanceof Problem)) throw e;
      const errors: Record<string, string> = {
        forbidden: "Cette action est réservée à un administrateur du groupe.",
        membership_revoked:
          "Ton accès a été retiré. Demande à un administrateur de le rétablir.",
        group_forbidden:
          "Tu n’as pas accès à ce groupe. Écris « Nanba rejoindre » pour demander ton inscription ici.",
        not_found:
          "Je ne trouve pas ce code dans cette discussion. Écris « Nanba demandes ».",
        invalid_threshold: "Indique un seuil entre 2 et 500 personnes.",
        interest_closed:
          "Cette demande est terminée ; aucun nouvel intérêt n’a été enregistré.",
        proposal_incomplete:
          "Complète les informations demandées avant de confirmer.",
      };
      reply =
        errors[e.code] ??
        "Je n’ai pas pu enregistrer cette action. Vérifie les informations ou écris « Nanba aide ».";
    }
    const r = a.createRecord(actor, "assistant_reply", "approved", {
      title: "Réponse automatique Nanba",
      text: "🤝 Nanba · " + reply,
      replyTo: p.id,
      identityHash: p.identityHash,
      automatic: true,
    });
    a.enqueue(
      actor,
      r,
      "assistant",
      {},
      "assistant:" +
        p.provider +
        ":" +
        p.session +
        ":" +
        p.groupId +
        ":" +
        p.id,
    );
    return true;
  }
  find(c: Context, code: string, kinds?: string[]): Entity {
    check(/^[a-f0-9-]{8,36}$/i.test(code), "not_found", 404);
    const rows = this.app.db.all(
      "SELECT id FROM records WHERE group_id=? AND substr(id,1,?)=?",
      c.groupId,
      code.length,
      code.toLowerCase(),
    );
    const visible = rows
      .map((r) => this.app.raw(r.id))
      .filter(
        (r) => (!kinds || kinds.includes(r.kind)) && this.app.canRead(c, r),
      );
    check(visible.length === 1, "not_found", 404);
    return visible[0];
  }
  respond(c: Context, p: Row, content: string, command: string): string {
    const a = this.app;
    a.db.run("DELETE FROM conversations WHERE expires_at<=?", a.now());
    const saved = a.db.get(
      "SELECT state FROM conversations WHERE group_id=? AND identity_hash=?",
      c.groupId,
      p.identityHash,
    );
    const state = saved ? parse(saved.state) : null;
    const put = (s: Row) =>
      a.db.run(
        "INSERT INTO conversations VALUES(?,?,?,?) ON CONFLICT(group_id,identity_hash) DO UPDATE SET state=excluded.state,expires_at=excluded.expires_at",
        c.groupId,
        p.identityHash,
        json(s),
        a.now() + 86400000,
      );
    const clear = () =>
      a.db.run(
        "DELETE FROM conversations WHERE group_id=? AND identity_hash=?",
        c.groupId,
        p.identityHash,
      );
    if (["annuler", "cancel"].includes(command)) {
      clear();
      return "Préparation annulée. Aucune nouvelle demande n’a été créée.";
    }
    if (/^(proposer|propose)\b/.test(command)) {
      const title = content.replace(/^(proposer|propose)\s*/i, "").trim();
      put({ step: title ? "city" : "title", title: title.slice(0, 160) });
      return title
        ? "Dans quelle ville ? Réponds par exemple « Nanba Paris »."
        : "Quelle idée veux-tu proposer ? Réponds par exemple « Nanba une sortie à Disneyland ».";
    }
    if (state) {
      if (state.step === "title") {
        state.title = text(content, "title", 160);
        state.step = "city";
        put(state);
        return "Dans quelle ville ? Exemple : « Nanba Paris ».";
      }
      if (state.step === "city") {
        state.city = text(content, "zone", 120);
        state.step = "when";
        put(state);
        return "Pour quand ? Exemple : « Nanba dimanche prochain ». Le créneau restera à confirmer avec l’organisateur.";
      }
      if (state.step === "when") {
        state.when = text(content, "slots", 300);
        state.step = "threshold";
        put(state);
        return "À partir de combien de personnes ? Réponds « Nanba 3 » (minimum 2).";
      }
      if (state.step === "threshold") {
        const n = Number(content);
        check(Number.isInteger(n) && n >= 2 && n <= 500, "invalid_threshold");
        state.threshold = n;
        state.step = "confirm";
        put(state);
        return `Récapitulatif : ${state.title}\nVille : ${state.city}\nCréneau souhaité : ${state.when}\nSeuil : ${n} personnes\nBudget : non renseigné.\nÉcris « Nanba confirmer » pour enregistrer la proposition dans cette discussion, ou « Nanba annuler ». Ce n’est pas une réservation.`;
      }
      if (state.step === "confirm" && command === "confirmer") {
        const r = a.request(c, {
          title: state.title,
          description: state.title,
          zone: state.city,
          slots: state.when,
          threshold: state.threshold,
          budget: null,
          language: "fr",
          category: "Proposition WhatsApp",
          deadline: a.now() + 7 * 86400000,
        });
        clear();
        return `Proposition enregistrée : ${state.title}\nCode : ${short(r)}\nUn administrateur peut lancer le sondage avec « Nanba sondage ${short(r)} ». Écris « Nanba résultats ${short(r)} » pour suivre les intérêts. Aucune réservation ni aucun paiement.`;
      }
      return "Écris « Nanba confirmer » pour enregistrer cette proposition, ou « Nanba annuler ».";
    }
    const code = content.split(/\s+/)[1] ?? "";
    if (/^sondage\b/.test(command)) {
      a.admin(c);
      const r = this.find(c, code, ["request"]);
      a.publishPoll(c, r, {});
      return "Le sondage est placé dans la file d’envoi de cette discussion. Il apparaîtra ici après confirmation de WhatsApp. Un vote exprime un intérêt, pas une réservation.";
    }
    if (/^resultats\b/.test(command) && code) {
      const r = this.find(c, code, ["request"]),
        n = a.counts(r.id);
      return `${r.data.title} · ${short(r)}\n${n.total} intérêt(s), seuil ${r.data.threshold}.\n${n.verified} profil(s) liés, ${n.provisional} intérêt(s) WhatsApp non liés ; ${n.uncertain} vote(s) incertain(s).\n${n.total >= r.data.threshold ? "Seuil atteint : une offre doit encore être confirmée par un partenaire." : "Le seuil n’est pas encore atteint."}\nAucune réservation ni aucun paiement.`;
    }
    if (/^(interet|interesse)\b/.test(command)) {
      const r = this.find(c, code, ["request"]),
        n = a.interest(c, r, true);
      return `Ton intérêt est enregistré pour « ${r.data.title} » : ${n.total}/${r.data.threshold}. Ce n’est pas une réservation.`;
    }
    if (/^(logement|housing)\b/.test(command))
      return "Pour le logement, ne publie pas de dossier personnel dans un groupe. Les demandes sont privées et partagées uniquement avec les professionnels que tu autorises. Aucune offre de logement réelle n’est connectée à ce pilote ; je ne peux pas confirmer de disponibilité.";
    if (/^(rechercher|recherche|search)\b/.test(command)) {
      const query = content.replace(/^\S+\s*/, "");
      check(query, "invalid_query");
      const hits = new Knowledge(a).search(c, query).slice(0, 3);
      return hits.length
        ? hits
            .map((h) => `${h.title}\n${h.excerpt}\nSource : ${h.url}`)
            .join("\n\n")
        : "Je n’ai pas de source vérifiée sur ce sujet dans cette discussion. Je préfère ne pas inventer une réponse. Écris « Nanba aide » pour voir les actions disponibles.";
    }
    const categories: Record<string, string> = {
      demandes: "request",
      resultats: "request",
      rencontres: "meetup",
      evenements: "meetup",
      offres: "offer",
      radar: "radar",
      arrivee: "cohort",
      defis: "challenge",
      histoires: "story",
      entraide: "help",
    };
    const kind = categories[command];
    if (kind) {
      const allowed: Record<string, string[]> = {
        request: ["proposed", "open"],
        meetup: ["open"],
        offer: ["confirmed"],
        radar: ["published"],
        cohort: ["open"],
        challenge: ["registration", "active", "closed", "completed"],
        story: ["published"],
        help: ["open"],
      };
      const rows = a
        .list(c, kind)
        .filter(
          (r) =>
            allowed[kind].includes(r.status) &&
            (r.data.expiresAt ?? Infinity) > a.now() &&
            (r.data.deadline ?? Infinity) > a.now() &&
            (kind !== "story" || r.data.audiences.includes("whatsapp")),
        )
        .slice(0, 5);
      return rows.length
        ? rows
            .map(
              (r) =>
                `${short(r)} · ${r.data.title}${r.data.zone ? " — " + r.data.zone : ""}${kind === "request" ? " · " + a.counts(r.id).total + "/" + r.data.threshold + " intérêts" : ""}`,
            )
            .join("\n")
        : "Aucun élément confirmé disponible dans cette discussion pour le moment. Tu peux commencer avec « Nanba proposer une sortie ».";
    }
    return "Je peux déjà t’aider à proposer une activité, lancer un sondage et lire les données de cette discussion. Pour une conversation libre et des recherches externes, le fournisseur IA reste à connecter. Écris « Nanba aide » ou « Nanba proposer une sortie ».";
  }
}
