import { uid, type Row } from "./db.ts";
import { hash, passwordHash, safeEqual } from "./auth.ts";
import { check, text } from "./validation.ts";
import type { Domain } from "./modules.ts";
import type { Context } from "./core.ts";
import { WahaConnector } from "./whatsapp.ts";

export function setupAvailable(a: Domain, expected: string) {
  return (
    /^[a-f0-9]{64}$/.test(expected) && !a.db.get("SELECT id FROM users LIMIT 1")
  );
}
export function setupOwner(a: Domain, input: Row, expected: string) {
  check(setupAvailable(a, expected), "setup_closed", 409);
  check(
    safeEqual(hash(text(input.key, "key", 150)), expected),
    "invalid_setup_key",
    403,
  );
  const email = text(input.email, "email", 250).toLowerCase();
  check(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email), "invalid_email");
  const name = text(input.name, "name", 120);
  const password = text(input.password, "password", 200);
  check(password.length >= 14, "password_too_short");
  const encoded = passwordHash(password);
  return a.db.tx(() => {
    check(setupAvailable(a, expected), "setup_closed", 409);
    const id = uid();
    a.db.run("INSERT INTO communities VALUES('pilot','Nanba Ensemble pilote')");
    a.db.run(
      "INSERT INTO groups(id,community_id,name,zone,allowed) VALUES('pilot','pilot','Nanba · groupe de test','France',0)",
    );
    a.db.run(
      "INSERT INTO users VALUES(?,?,?,?,1,NULL,'{}',0,?)",
      id,
      email,
      name,
      encoded,
      a.now(),
    );
    a.db.run("INSERT INTO memberships VALUES(?,'pilot','group_admin',1)", id);
    a.audit({ userId: id, groupId: "pilot" }, "pilot.owner_created", id);
    return { id, email };
  });
}
export class Pilot {
  app: Domain;
  connector: WahaConnector;
  origin: string;
  webhookSecret: string;
  constructor(
    app: Domain,
    connector: WahaConnector,
    origin: string,
    webhookSecret: string,
  ) {
    this.app = app;
    this.connector = connector;
    this.origin = origin;
    this.webhookSecret = webhookSecret;
  }
  authorize(c: Context) {
    check(this.app.admin(c).platform_admin, "platform_admin_required", 403);
  }
  async status(c: Context) {
    this.authorize(c);
    let state;
    try {
      state = await this.connector.request(
        "/api/sessions/" + encodeURIComponent(this.connector.session),
      );
    } catch (e) {
      if (e instanceof Error && e.message === "provider_http_404")
        return { status: "NOT_CREATED", connected: false };
      throw e;
    }
    return {
      status: state.status,
      connected: state.status === "WORKING",
      session: this.connector.session,
    };
  }
  async connect(c: Context) {
    this.authorize(c);
    const current = await this.status(c);
    if (["WORKING", "STARTING", "SCAN_QR_CODE"].includes(current.status))
      return current;
    check(current.status !== "FAILED", "session_failed_manual_review", 409);
    const config = {
      webhooks: [
        {
          url: this.origin + "/api/webhooks/waha",
          events: [
            "message",
            "poll.vote",
            "poll.vote.failed",
            "session.status",
          ],
          hmac: { key: this.webhookSecret },
          retries: { policy: "exponential", delaySeconds: 2, attempts: 10 },
        },
      ],
    };
    if (current.status === "NOT_CREATED")
      await this.connector.request("/api/sessions", {
        name: this.connector.session,
        start: true,
        config,
      });
    else {
      await this.connector.request(
        "/api/sessions/" + encodeURIComponent(this.connector.session),
        { config },
        "PUT",
      );
      await this.connector.request(
        "/api/sessions/" +
          encodeURIComponent(this.connector.session) +
          "/start",
        {},
      );
    }
    this.app.audit(c, "pilot.session_start_requested");
    return this.status(c);
  }
  async qr(c: Context) {
    this.authorize(c);
    const state = await this.status(c);
    check(state.status === "SCAN_QR_CODE", "qr_not_ready", 409);
    const result = await this.connector.request(
      "/api/" + encodeURIComponent(this.connector.session) + "/auth/qr",
    );
    check(
      result.mimetype === "image/png" &&
        typeof result.data === "string" &&
        result.data.length < 500000 &&
        /^[a-zA-Z0-9+/=]+$/.test(result.data),
      "invalid_qr_response",
      502,
    );
    return { image: "data:image/png;base64," + result.data };
  }
  async groups(c: Context) {
    this.authorize(c);
    const list = await this.connector.request(
      "/api/" +
        encodeURIComponent(this.connector.session) +
        "/groups?limit=100&offset=0",
    );
    const entries = Array.isArray(list) ? list : Object.values(list);
    return entries
      .map((g: any) => ({
        id: typeof g.id === "string" ? g.id : g.id?._serialized,
        name: String(g.subject ?? g.name ?? "Groupe WhatsApp"),
      }))
      .filter((g) => typeof g.id === "string" && g.id.endsWith("@g.us"));
  }
  async bind(c: Context, input: Row) {
    this.authorize(c);
    check(input.authorized === true, "group_consent_required", 403);
    const id = text(input.chatId, "chatId", 150);
    check(/^\d+(?:-\d+)?@g\.us$/.test(id), "invalid_group");
    const g = await this.connector.request(
      "/api/" +
        encodeURIComponent(this.connector.session) +
        "/groups/" +
        encodeURIComponent(id),
    );
    const providerId = typeof g.id === "string" ? g.id : g.id?._serialized;
    check(providerId === id, "group_not_confirmed", 409);
    return this.app.db.tx(() => {
      this.app.db.run(
        "UPDATE outbox SET status='cancelled',error='pilot_group_changed',updated_at=? WHERE group_id=? AND status IN('pending','prepared')",
        this.app.now(),
        c.groupId,
      );
      this.app.db.run(
        "UPDATE groups SET chat_id=?,name=?,allowed=1,paused=0 WHERE id=?",
        id,
        String(g.subject ?? g.name ?? "Groupe de test").slice(0, 120),
        c.groupId,
      );
      this.app.audit(c, "pilot.group_authorized", c.groupId);
      return { id: c.groupId, name: g.subject ?? g.name ?? "Groupe de test" };
    });
  }
  poll(c: Context) {
    this.authorize(c);
    const g = this.app.group(c);
    check(g.allowed && g.chat_id && !g.paused, "group_not_authorized", 403);
    const recent = this.app.db.get(
      "SELECT id FROM records WHERE group_id=? AND kind='request' AND json_extract(data,'$.category')='Test pilote' AND created_at>?",
      c.groupId,
      this.app.now() - 60000,
    );
    check(!recent, "pilot_poll_cooldown", 429);
    const r = this.app.create(c, "request", {
      title: "Test Nanba Ensemble · souhaitez-vous participer ?",
      description:
        "Sondage de vérification du groupe pilote. Aucune réservation ni aucun paiement.",
      category: "Test pilote",
      zone: g.zone,
      language: "fr",
      slots: "Test uniquement",
      budget: 0,
      threshold: 1,
      deadline: this.app.now() + 86400000,
    });
    const poll = this.app.action(c, r.id, "publish_poll");
    return { requestId: r.id, pollId: poll.id, status: "pending" };
  }
}
