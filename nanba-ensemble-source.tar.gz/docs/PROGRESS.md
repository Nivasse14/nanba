# État de réalisation — Nanba Ensemble

Mis à jour le 12 novembre 2026. Spécification intégrale : [SPECIFICATION.txt](SPECIFICATION.txt).

## Point de départ et portée livrée

Aucun dépôt Nanba existant, endpoint métier, SSO, logo ni compte fournisseur n’était accessible. Application autonome et intégrable : TypeScript / Node 24, SQLite transactionnel, API HTTP, sessions, interface FR/EN responsive, rôles et administration. Le raccordement au vrai Nanba reste à effectuer.

Les huit parcours fonctionnent localement avec persistance. Le mode simulé est isolé : inscriptions locales, aucun paiement ou réservation externe, aucun message WhatsApp réel. Les dépendances absentes sont refusées explicitement ou représentées par des interfaces ; elles ne produisent pas de faux succès.

## Plan réalisé

- [x] Lire toute la spécification, examiner les fichiers et les instructions.
- [x] Fondations et chaîne complète du premier module.
- [x] Sept autres modules et écrans reliés au backend.
- [x] Permissions par groupe/organisation, consentements, audit et effacement.
- [x] Transports simulé/WAHA, inbox/outbox, pause et reprise.
- [x] Collecte, connaissances, brouillons IA, digests et administration.
- [x] Validations locales, documentation et livraison reproductible.
- [ ] Raccordement au vrai Nanba et recette des services externes autorisés.

## Matrice fonctionnelle et preuves

| Module | Fonctionnel localement | Tests réellement exécutés | Activation externe / limites restantes |
|---|---|---|---|
| 1. Demandes collectives | Besoin, intérêts, sondage validé, votes, seuil, offre confirmée par son auteur, conditions versionnées, inscriptions, attente, annulation | Domaine + HTTP de bout en bout, redémarrage, changements/retraits/doublons/votes tardifs, ambiguïtés, seuil unique, six connexions simultanées pour une place, réacceptation | Compte WAHA et recette moteur réelle ; partenaire réel ; fournisseur de paiement éventuel |
| 2. Petites rencontres | Création, rapprochement explicable, capacité, attente, proposition de place avec expiration, coordination protégée, ICS | Accès à la coordination, désistement, promotion et expiration de place ; capacité | Notification WhatsApp réelle ; lieu/organisateur à confirmer hors application |
| 3. Logement | Demande privée, professionnels choisis, propositions référencées, disponibilité datée, intérêt/contact, révocation, pause et retour | Isolation groupes/organisations, refus à l’admin non autorisé, révocation immédiate, disponibilité périmée | Catalogue, comptes et abonnements professionnels Nanba ; aucune disponibilité de bien réel vérifiée |
| 4. Entraide | Profil, compétences/langues, plages horaires, limite hebdomadaire, pause, proposition, double accord, annulation et retour | Chevauchements, limite et pause, double acceptation, libération du créneau et effacement du volontaire | Notifications réelles ; aucun fournisseur nécessaire au parcours local |
| 5. Radar | Provenance, observation, expiration par catégorie, modération, dédoublonnage, correction, contestation, reconfirmation versionnée | Horloge contrôlée, disparition après expiration, reconfirmation, sources administratives et protection de la collecte | Sources réelles et modérateurs à configurer ; collecte réseau réelle non recettée |
| 6. Nouveaux arrivants | Cohortes, thèmes, étapes, ressources, inscriptions, activités rejointes, progression privée, mentorat | Persistance et confidentialité de la progression, activité soumise à inscription préalable | Contenus officiels et mentors réels à sélectionner ; notification externe |
| 7. Défis entre villes | Préparation, validation du contenu, équipes, inscriptions, effectif figé, réponses uniques, résultat calculé, contestation/correction tracée, carte SVG | Calcul reproductible, dénominateur figé, réponses doubles et tardives rejetées | Éditorial réel à valider ; publication WhatsApp |
| 8. Histoires familiales | Original/traduction, accord auteur par version/canal, validation éditoriale, carte bilingue, retrait | Refus sans consentement, changement invalidant l’accord, retrait masquant les surfaces et annulant les publications en attente | Traduction/transcription automatiques et stockage média non branchés ; saisie bilingue manuelle opérationnelle ; tamoul/Tanglish non évalués |

## Résultats de validation

Environnement : Node 24.22.1, SQLite natif. Bases jetables et données synthétiques indépendantes de la démonstration.

| Commande / contrôle | Résultat observé |
|---|---|
| `npm run check` | Build et vérification TypeScript réussis ; **37 tests réussis, 0 échec, 0 ignoré** |
| `node --check public/app.js` | Syntaxe du client valide |
| `npm run format:check` | Formatage conforme |
| `npm audit --json` | 0 vulnérabilité npm signalée ; ne couvre pas WAHA, Node ou l’hôte |
| `npm run backup`, puis `PRAGMA integrity_check` sur la copie | Sauvegarde créée, résultat `ok`, 12 enregistrements métier conservés |
| Navigateur ordinateur | Profils synthétiques, création d’une demande, intérêt, validation de sondage et traitement simulé, administration, bascule FR/EN, fiche bilingue ; accueil final contrôlé visuellement |

Preuves textuelles : `validation-output.txt`. Tests : `tests/domain.test.ts`, `tests/http.test.ts`, `tests/transport.test.ts`.

Autres validations : HMAC SHA-512 sur corps brut, isolation sessions/groupes, options/timestamps WAHA, déchiffrement en échec distinct d’un retrait, déconnexion, timeout durable `uncertain`, reprise sans doublon, révocation avant envoi, pause annulant les tâches, déduplication de digest, SSRF/XML interdits, refus de faux paiement, export/effacement et panne IA sans blocage métier.

## Problèmes corrigés

Paramètres SQL de votes/commandes ; visibilité des offres modifiées pour les inscrits devant reconfirmer ; maintien de la position d’attente après répétition ; absence de promotion après annulation ; annulation des inscriptions lors de l’effacement d’un organisateur ; libération des créneaux du volontaire supprimé ; types des boutons de formulaire ; dates Europe/Paris ; port de prévisualisation ; séparation du compose WAHA optionnel.

## Limites non couvertes localement

Aucun conteneur Docker exécuté, compte WhatsApp connecté, message tiers envoyé, fournisseur IA réel appelé, paiement effectué ou déploiement public. Contrats WAHA vérifiés contre la documentation 2026.10.1 et des réponses synthétiques, sans certification en situation réelle. WEBJS ne fournit pas ici d’événement natif, fermeture/édition native de sondage ou masquage des votants.

Le navigateur n’a pas permis une recette à largeur mobile réelle. Responsive CSS livré ; validation sur appareils, accessibilité approfondie et charge restent à réaliser. Aucun bug bloquant connu dans les parcours testés ; cela ne constitue pas une certification de production.

## Reprise de session

1. Lire ce fichier, README.md et les limites de WHATSAPP.md / OPERATIONS.md.
2. Node 24.22.1+, puis `npm ci`, `npm run check`, `npm run dev`. Ne pas réinitialiser la base persistante existante.
3. Intégration Nanba : fournir dépôt/API/SSO, implémenter les ports de `src/integrations.ts`, réutiliser comptes et catalogue.
4. WAHA : compte pilote dédié, secrets, groupe autorisé, image épinglée et recette limitée selon OPERATIONS.md. Ne pas transformer une base simulée en base réelle.
5. Ajouter les autres fournisseurs un à un, effectuer leur recette puis actualiser cette matrice. Les actions externes gardent les autorisations requises.

## Préparation du pilote WhatsApp — suite

Budget Render 32,50 $/mois et déploiement approuvés. Ajout de l’activation propriétaire à usage unique et de l’écran de connexion WhatsApp (QR privé, groupe autorisé, sondage de test). **41 tests réussis**, TypeScript et schéma JSON du Blueprint valides. Publication GitHub effectuée sur `nanba-ensemble-pilot`, commit applicatif `4f920410db67f47f4c118f490974c15d0758ee7c`. Après ajout de la carte par le propriétaire, le Blueprint `exs-dbr32mg8v5cc738qeue0` a créé l’application et WAHA privé avec deux disques persistants. Le site `https://nanba-ensemble-pilot-ufgg.onrender.com` répond en mode réel, sans démonstration; activation à usage unique disponible. Six contrôles GET et un refus de mauvaise clé POST validés à distance, plus vérification navigateur. Correction du port privé WAHA vers 10000 et suppression des QR dans les logs. Les tests téléphone, QR et sondage réel restent à faire avec le propriétaire. Détails, ressources et reprise dans DEPLOYMENT.md; preuves dans live-validation.json.

## Assistant utilisable directement dans WhatsApp — 12 novembre 2026

Réponses automatiques guidées et test personnel sans compte web ajoutés : lien privé, QR, activation de la discussion « Vous », menu, proposition en plusieurs étapes, confirmation, sondage, résultats, consultation des contenus autorisés et recherche de sources validées. Migration 002 persistante. 48 tests locaux réussis, compilation et syntaxe navigateur validées. L’IA généraliste n’est pas configurée ; les réponses ne prétendent pas être générées par un modèle connecté. Aucun message téléphonique réel vérifié avant association par le propriétaire. Les résultats précédents de ce fichier sont historiques ; les services Render et WAHA sont désormais déployés, voir DEPLOYMENT.md.
