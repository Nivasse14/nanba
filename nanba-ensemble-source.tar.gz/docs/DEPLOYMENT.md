# Pilote WhatsApp — 12 novembre 2026

Déploiement autorisé sur Render, My Workspace. Budget approuvé : application 512 Mo à 7 $/mois, WAHA 2 Go à 25 $/mois, deux volumes 1 Go à 0,50 $/mois au total. Région Frankfurt, services privés/publics séparés, aucune donnée de démonstration en production.

Branche `nanba-ensemble-pilot`, dossier `ensemble`, Blueprint `ensemble/render.yaml`. Aucun changement au code mobile existant. Synchronisation et déploiement automatiques désactivés. Secrets API/HMAC/chiffrement générés par Render et partagés par références, jamais en Git.

`PILOT_SETUP_HASH` est ajouté séparément via la configuration Render. Il contient uniquement le SHA-256 d’une clé d’activation aléatoire. Cette clé est remise au propriétaire dans un fichier privé, n’apparaît ni dans les logs ni dans Git. L’activation exige ce secret et crée un seul administrateur ; elle est fermée dès le premier compte.

Le propriétaire définit son mot de passe puis ouvre Connexion WhatsApp. Il demande le QR, le scanne depuis le téléphone du bot, choisit un groupe consentant et peut envoyer un vrai sondage de test. Le serveur reste capable de gérer les inscriptions pendant une déconnexion du transport. Les réponses aux commandes restent des brouillons administratifs. Fournisseur IA et paiement non connectés.

WAHA session `default`, WEBJS 2026.10.1. Le code source officiel épinglé confirme GET /api/{session}/auth/qr, PUT /api/sessions/{session}, POST /api/sessions et POST /api/sessions/{session}/start. Le QR n’est accessible qu’au compte plateforme authentifié ; aucun accès direct public à WAHA.

Validation locale : 41 tests réussis, compilation TypeScript réussie, schéma JSON du Blueprint valide. La validation Render et les contrôles après déploiement sont suivis séparément.
